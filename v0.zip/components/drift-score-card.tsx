"use client"

import { cn } from "@/lib/utils"

interface DriftScoreCardProps {
  score: number
  status: "normal" | "warning" | "critical"
  className?: string
}

export function DriftScoreCard({ score, status, className }: DriftScoreCardProps) {
  const getStatusColor = () => {
    switch (status) {
      case "normal":
        return "text-success"
      case "warning":
        return "text-warning"
      case "critical":
        return "text-destructive"
      default:
        return "text-foreground"
    }
  }

  const getStatusLabel = () => {
    switch (status) {
      case "normal":
        return "Optimal Performance"
      case "warning":
        return "Mild Drift Detected"
      case "critical":
        return "Critical Drift Alert"
      default:
        return "Unknown"
    }
  }

  const getGlowColor = () => {
    switch (status) {
      case "normal":
        return "shadow-success/20"
      case "warning":
        return "shadow-warning/20"
      case "critical":
        return "shadow-destructive/20"
      default:
        return ""
    }
  }

  return (
    <div
      className={cn(
        "relative flex flex-col items-center justify-center rounded-3xl bg-card border border-border p-8 md:p-12 shadow-2xl transition-all duration-500",
        getGlowColor(),
        className
      )}
    >
      <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
      
      <span className="text-xs uppercase tracking-widest text-muted-foreground mb-4">
        Drift Score
      </span>
      
      <div className="relative">
        <span
          className={cn(
            "text-7xl md:text-9xl font-light tabular-nums transition-colors duration-500",
            getStatusColor()
          )}
        >
          {score.toFixed(1)}
        </span>
        <span className={cn("absolute -right-6 top-4 text-2xl", getStatusColor())}>%</span>
      </div>
      
      <div className="mt-6 flex items-center gap-2">
        <span
          className={cn(
            "h-2 w-2 rounded-full animate-pulse",
            status === "normal" && "bg-success",
            status === "warning" && "bg-warning",
            status === "critical" && "bg-destructive"
          )}
        />
        <span className="text-sm text-muted-foreground">{getStatusLabel()}</span>
      </div>
    </div>
  )
}
