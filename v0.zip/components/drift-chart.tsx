"use client"

import {
  Area,
  AreaChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
} from "recharts"
import { cn } from "@/lib/utils"

interface DriftDataPoint {
  time: string
  drift: number
  threshold?: number
}

interface DriftChartProps {
  data: DriftDataPoint[]
  className?: string
}

export function DriftChart({ data, className }: DriftChartProps) {
  return (
    <div
      className={cn(
        "rounded-2xl bg-card border border-border p-6 shadow-lg",
        className
      )}
    >
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-medium text-foreground">Drift Over Time</h3>
          <p className="text-xs text-muted-foreground mt-1">Last 12 hours</p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-primary" />
            <span className="text-muted-foreground">Drift Score</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-0.5 w-4 bg-warning" />
            <span className="text-muted-foreground">Threshold</span>
          </div>
        </div>
      </div>
      
      <div className="h-[200px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="driftGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.65 0.2 250)" stopOpacity={0.4} />
                <stop offset="100%" stopColor="oklch(0.65 0.2 250)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="time"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "oklch(0.55 0 0)", fontSize: 10 }}
              dy={10}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fill: "oklch(0.55 0 0)", fontSize: 10 }}
              domain={[0, 100]}
              ticks={[0, 25, 50, 75, 100]}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "oklch(0.15 0.005 260)",
                border: "1px solid oklch(0.22 0.01 260)",
                borderRadius: "12px",
                boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
              }}
              labelStyle={{ color: "oklch(0.98 0 0)", fontSize: 12 }}
              itemStyle={{ color: "oklch(0.65 0.2 250)", fontSize: 12 }}
              formatter={(value: number) => [`${value.toFixed(1)}%`, "Drift"]}
            />
            <ReferenceLine
              y={70}
              stroke="oklch(0.8 0.18 85)"
              strokeDasharray="4 4"
              strokeWidth={1}
            />
            <Area
              type="monotone"
              dataKey="drift"
              stroke="oklch(0.65 0.2 250)"
              strokeWidth={2}
              fill="url(#driftGradient)"
              animationDuration={1000}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
