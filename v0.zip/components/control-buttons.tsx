"use client"

import { Play, Flame, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ControlButtonsProps {
  isRunning: boolean
  onStartSimulation: () => void
  onTriggerBurnout: () => void
  onReset: () => void
  className?: string
}

export function ControlButtons({
  isRunning,
  onStartSimulation,
  onTriggerBurnout,
  onReset,
  className,
}: ControlButtonsProps) {
  return (
    <div className={cn("flex flex-wrap items-center gap-3", className)}>
      <Button
        onClick={onStartSimulation}
        variant={isRunning ? "secondary" : "default"}
        className="gap-2 rounded-xl px-5"
      >
        <Play className={cn("h-4 w-4", isRunning && "animate-pulse")} />
        {isRunning ? "Running..." : "Start Simulation"}
      </Button>
      
      <Button
        onClick={onTriggerBurnout}
        variant="outline"
        className="gap-2 rounded-xl px-5 border-destructive/30 text-destructive hover:bg-destructive/10 hover:text-destructive hover:border-destructive/50"
      >
        <Flame className="h-4 w-4" />
        Trigger Burnout
      </Button>
      
      <Button
        onClick={onReset}
        variant="ghost"
        className="gap-2 rounded-xl px-5 text-muted-foreground hover:text-foreground"
      >
        <RotateCcw className="h-4 w-4" />
        Reset State
      </Button>
    </div>
  )
}
