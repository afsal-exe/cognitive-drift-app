"use client"

import { useEffect, useState } from "react"
import { X, AlertTriangle, RefreshCw } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface NotificationPopupProps {
  show: boolean
  onClose: () => void
  onStartRecovery?: () => void
  title?: string
  message?: string
  explanation?: string
}

export function NotificationPopup({
  show,
  onClose,
  onStartRecovery,
  title = "Performance Intervention Required",
  message = "Cognitive drift has exceeded safe thresholds. Consider taking a break or initiating recovery mode.",
  explanation = "",
}: NotificationPopupProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [progress, setProgress] = useState(100)

  useEffect(() => {
    if (show) {
      setIsVisible(true)
      setProgress(100)
    } else {
      const timer = setTimeout(() => setIsVisible(false), 300)
      return () => clearTimeout(timer)
    }
  }, [show])

  // Animate progress bar
  useEffect(() => {
    if (!show) return
    
    const duration = 8000 // 8 seconds
    const interval = 50
    const decrement = (100 / duration) * interval

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev <= 0) {
          clearInterval(timer)
          return 0
        }
        return prev - decrement
      })
    }, interval)

    return () => clearInterval(timer)
  }, [show])

  if (!isVisible && !show) return null

  return (
    <div
      className={cn(
        "fixed bottom-6 right-6 z-50 w-[380px] transition-all duration-300 ease-out",
        show ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
      )}
    >
      <div className="relative overflow-hidden rounded-2xl bg-card border border-border shadow-2xl">
        <div className="absolute inset-0 bg-gradient-to-br from-destructive/10 to-transparent pointer-events-none" />
        
        <div className="relative p-5">
          <div className="flex items-start gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-destructive/20">
              <AlertTriangle className="h-5 w-5 text-destructive" />
            </div>
            
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-medium text-foreground pr-6">{title}</h4>
              <p className="mt-1 text-xs text-muted-foreground leading-relaxed">
                {message}
              </p>
              
              {explanation && (
                <div className="mt-3 p-2.5 rounded-lg bg-secondary/50 border border-border">
                  <p className="text-xs font-medium text-foreground mb-1">Analysis:</p>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {explanation}
                  </p>
                </div>
              )}
              
              <div className="mt-4 flex gap-2">
                {onStartRecovery && (
                  <Button
                    size="sm"
                    onClick={onStartRecovery}
                    className="text-xs gap-1.5"
                  >
                    <RefreshCw className="h-3 w-3" />
                    Start Recovery
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={onClose}
                  className="text-xs text-muted-foreground"
                >
                  Dismiss
                </Button>
              </div>
            </div>
            
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        <div className="h-1 bg-destructive/20">
          <div
            className="h-full bg-destructive transition-all duration-100 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  )
}
