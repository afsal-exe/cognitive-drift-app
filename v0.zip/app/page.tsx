"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Keyboard, AlertCircle, Layers, Moon, Activity } from "lucide-react"
import { DriftScoreCard } from "@/components/drift-score-card"
import { MetricCard } from "@/components/metric-card"
import { DriftChart } from "@/components/drift-chart"
import { NotificationPopup } from "@/components/notification-popup"
import { ControlButtons } from "@/components/control-buttons"

interface MetricsState {
  driftScore: number
  typingSpeed: number
  errorRate: number
  appSwitching: number
  sleepScore: number
}

interface MetricsHistory {
  timestamp: number
  metrics: MetricsState
}

interface DriftDataPoint {
  time: string
  drift: number
}

const initialMetrics: MetricsState = {
  driftScore: 12.4,
  typingSpeed: 78,
  errorRate: 2.1,
  appSwitching: 4,
  sleepScore: 85,
}

const DRIFT_THRESHOLD = 70
const RAPID_DEGRADATION_WINDOW = 10 // Number of history entries to check
const RAPID_DEGRADATION_RATE = 15 // Drift increase threshold for rapid degradation

const generateInitialChartData = (): DriftDataPoint[] => {
  const data: DriftDataPoint[] = []
  const now = new Date()
  for (let i = 11; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 60 * 60 * 1000)
    data.push({
      time: time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      drift: 10 + Math.random() * 15,
    })
  }
  return data
}

// Function that explains why drift increased
function generateDriftExplanation(
  currentMetrics: MetricsState,
  historyStart: MetricsState | null
): string {
  if (!historyStart) {
    return "Insufficient data to analyze drift patterns."
  }

  const explanations: string[] = []
  
  // Calculate changes
  const typingSpeedChange = ((historyStart.typingSpeed - currentMetrics.typingSpeed) / historyStart.typingSpeed) * 100
  const errorRateChange = ((currentMetrics.errorRate - historyStart.errorRate) / Math.max(historyStart.errorRate, 0.1)) * 100
  const appSwitchingChange = ((currentMetrics.appSwitching - historyStart.appSwitching) / Math.max(historyStart.appSwitching, 1)) * 100
  const sleepScoreChange = ((historyStart.sleepScore - currentMetrics.sleepScore) / historyStart.sleepScore) * 100

  // Typing speed decrease
  if (typingSpeedChange > 5) {
    explanations.push(`Typing speed dropped ${Math.round(typingSpeedChange)}%`)
  }

  // Error rate increase
  if (errorRateChange > 10) {
    explanations.push(`error rate increased ${Math.round(errorRateChange)}%`)
  }

  // App switching spike
  if (appSwitchingChange > 20) {
    explanations.push(`app switching spiked ${Math.round(appSwitchingChange)}%`)
  }

  // Sleep score decline
  if (sleepScoreChange > 10) {
    explanations.push(`sleep score declined ${Math.round(sleepScoreChange)}%`)
  }

  if (explanations.length === 0) {
    return "Drift is within normal parameters."
  }

  const timeframe = "in the last 10 minutes"
  
  if (explanations.length === 1) {
    return `${explanations[0]} ${timeframe}.`
  }

  const lastExplanation = explanations.pop()
  return `${explanations.join(", ")} and ${lastExplanation} ${timeframe}.`
}

// Detect rapid degradation by checking rate of change
function detectRapidDegradation(history: MetricsHistory[]): boolean {
  if (history.length < RAPID_DEGRADATION_WINDOW) return false
  
  const recentHistory = history.slice(-RAPID_DEGRADATION_WINDOW)
  const oldestDrift = recentHistory[0].metrics.driftScore
  const newestDrift = recentHistory[recentHistory.length - 1].metrics.driftScore
  
  const driftIncrease = newestDrift - oldestDrift
  
  return driftIncrease >= RAPID_DEGRADATION_RATE
}

export default function Dashboard() {
  const [metrics, setMetrics] = useState<MetricsState>(initialMetrics)
  const [chartData, setChartData] = useState<DriftDataPoint[]>(generateInitialChartData)
  const [isRunning, setIsRunning] = useState(false)
  const [showNotification, setShowNotification] = useState(false)
  const [isRecovering, setIsRecovering] = useState(false)
  const [driftExplanation, setDriftExplanation] = useState<string>("")
  const [metricsHistory, setMetricsHistory] = useState<MetricsHistory[]>([])
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const recoveryIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const getStatus = useCallback((score: number) => {
    if (score < 40) return "normal" as const
    if (score < 70) return "warning" as const
    return "critical" as const
  }, [])

  // Recovery simulation - gradually improve metrics
  const simulateRecovery = useCallback(() => {
    setMetrics((prev) => {
      const newMetrics = {
        driftScore: Math.max(10, prev.driftScore - (2 + Math.random() * 2)),
        typingSpeed: Math.min(85, prev.typingSpeed + (1 + Math.random() * 2)),
        errorRate: Math.max(1.5, prev.errorRate - (0.3 + Math.random() * 0.3)),
        appSwitching: Math.max(3, prev.appSwitching - (0.5 + Math.random() * 0.5)),
        sleepScore: Math.min(90, prev.sleepScore + (1 + Math.random() * 1.5)),
      }

      // Stop recovery when drift is back to normal levels
      if (newMetrics.driftScore <= 25) {
        setIsRecovering(false)
        if (recoveryIntervalRef.current) {
          clearInterval(recoveryIntervalRef.current)
          recoveryIntervalRef.current = null
        }
      }

      return newMetrics
    })

    setChartData((prev) => {
      const newData = [...prev.slice(1)]
      const now = new Date()
      newData.push({
        time: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        drift: metrics.driftScore,
      })
      return newData
    })
  }, [metrics.driftScore])

  // Start recovery mode
  const startRecovery = useCallback(() => {
    // Pause normal simulation
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }
    setIsRunning(false)
    setIsRecovering(true)
    setShowNotification(false)

    // Start recovery interval
    recoveryIntervalRef.current = setInterval(simulateRecovery, 600)
  }, [simulateRecovery])

  const simulateMetrics = useCallback(() => {
    setMetrics((prev) => {
      const driftChange = (Math.random() - 0.35) * 4
      const newDrift = Math.max(0, Math.min(100, prev.driftScore + driftChange))
      
      return {
        driftScore: newDrift,
        typingSpeed: Math.max(30, Math.min(120, prev.typingSpeed + (Math.random() - 0.55) * 4)),
        errorRate: Math.max(0, Math.min(20, prev.errorRate + (Math.random() - 0.4) * 0.6)),
        appSwitching: Math.max(0, Math.min(30, prev.appSwitching + (Math.random() - 0.4) * 2.5)),
        sleepScore: Math.max(0, Math.min(100, prev.sleepScore + (Math.random() - 0.55) * 2)),
      }
    })

    setChartData((prev) => {
      const newData = [...prev.slice(1)]
      const now = new Date()
      newData.push({
        time: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        drift: metrics.driftScore,
      })
      return newData
    })
  }, [metrics.driftScore])

  // Track metrics history for degradation detection
  useEffect(() => {
    if (isRunning || isRecovering) {
      setMetricsHistory((prev) => {
        const newHistory = [...prev, { timestamp: Date.now(), metrics }]
        // Keep only last 20 entries
        return newHistory.slice(-20)
      })
    }
  }, [metrics, isRunning, isRecovering])

  // Intervention trigger logic
  useEffect(() => {
    if (showNotification || isRecovering) return

    const shouldTriggerIntervention =
      metrics.driftScore >= DRIFT_THRESHOLD ||
      detectRapidDegradation(metricsHistory)

    if (shouldTriggerIntervention) {
      // Generate explanation
      const historyStart = metricsHistory.length >= RAPID_DEGRADATION_WINDOW
        ? metricsHistory[metricsHistory.length - RAPID_DEGRADATION_WINDOW].metrics
        : metricsHistory[0]?.metrics || null

      const explanation = generateDriftExplanation(metrics, historyStart)
      setDriftExplanation(explanation)
      setShowNotification(true)
    }
  }, [metrics, metricsHistory, showNotification, isRecovering])

  const startSimulation = useCallback(() => {
    if (isRecovering) return // Don't allow starting simulation during recovery
    
    if (isRunning) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
        intervalRef.current = null
      }
      setIsRunning(false)
    } else {
      setIsRunning(true)
      intervalRef.current = setInterval(simulateMetrics, 800)
    }
  }, [isRunning, isRecovering, simulateMetrics])

  const triggerBurnout = useCallback(() => {
    const burnoutMetrics = {
      driftScore: 85 + Math.random() * 10,
      typingSpeed: 35 + Math.random() * 10,
      errorRate: 12 + Math.random() * 5,
      appSwitching: 18 + Math.random() * 8,
      sleepScore: 25 + Math.random() * 15,
    }

    setMetrics(burnoutMetrics)

    setChartData((prev) => {
      const newData = [...prev.slice(1)]
      const now = new Date()
      newData.push({
        time: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        drift: burnoutMetrics.driftScore,
      })
      return newData
    })

    // Generate explanation for burnout
    const historyStart = metricsHistory.length >= RAPID_DEGRADATION_WINDOW
      ? metricsHistory[metricsHistory.length - RAPID_DEGRADATION_WINDOW].metrics
      : metricsHistory[0]?.metrics || initialMetrics

    setDriftExplanation(generateDriftExplanation(burnoutMetrics, historyStart))
    setShowNotification(true)
  }, [metricsHistory])

  const resetState = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }
    if (recoveryIntervalRef.current) {
      clearInterval(recoveryIntervalRef.current)
      recoveryIntervalRef.current = null
    }
    setIsRunning(false)
    setIsRecovering(false)
    setMetrics(initialMetrics)
    setChartData(generateInitialChartData())
    setShowNotification(false)
    setMetricsHistory([])
    setDriftExplanation("")
  }, [])

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
      if (recoveryIntervalRef.current) {
        clearInterval(recoveryIntervalRef.current)
      }
    }
  }, [])

  const status = getStatus(metrics.driftScore)

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Header */}
        <header className="mb-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <Activity className="h-4 w-4 text-primary" />
            </div>
            <h1 className="text-xl font-medium text-foreground">
              Cognitive Drift Detection System
            </h1>
          </div>
          <p className="text-sm text-muted-foreground">
            Real-time cognitive performance monitoring and intervention system
          </p>
        </header>

        {/* Main Content */}
        <div className="grid gap-6 lg:grid-cols-12">
          {/* Left Column - Drift Score */}
          <div className="lg:col-span-5">
            <DriftScoreCard
              score={metrics.driftScore}
              status={status}
              className="h-full"
            />
          </div>

          {/* Right Column - Chart and Metrics */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <DriftChart data={chartData} />

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              <MetricCard
                label="Typing Speed"
                value={Math.round(metrics.typingSpeed)}
                unit="WPM"
                icon={Keyboard}
                trend={metrics.typingSpeed < 50 ? "down" : "neutral"}
                trendValue={metrics.typingSpeed < 50 ? "Low" : "Normal"}
              />
              <MetricCard
                label="Error Rate"
                value={metrics.errorRate.toFixed(1)}
                unit="%"
                icon={AlertCircle}
                trend={metrics.errorRate > 8 ? "up" : "neutral"}
                trendValue={metrics.errorRate > 8 ? "High" : "Normal"}
              />
              <MetricCard
                label="App Switching"
                value={Math.round(metrics.appSwitching)}
                unit="/hr"
                icon={Layers}
                trend={metrics.appSwitching > 12 ? "up" : "neutral"}
                trendValue={metrics.appSwitching > 12 ? "Frequent" : "Normal"}
              />
              <MetricCard
                label="Sleep Score"
                value={Math.round(metrics.sleepScore)}
                unit="/100"
                icon={Moon}
                trend={metrics.sleepScore < 50 ? "down" : "neutral"}
                trendValue={metrics.sleepScore < 50 ? "Poor" : "Good"}
              />
            </div>
          </div>
        </div>

        {/* Control Buttons */}
        <div className="mt-8 flex items-center justify-between border-t border-border pt-8">
          <ControlButtons
            isRunning={isRunning}
            onStartSimulation={startSimulation}
            onTriggerBurnout={triggerBurnout}
            onReset={resetState}
          />
          
          <div className="hidden sm:flex items-center gap-2 text-xs text-muted-foreground">
            {isRecovering ? (
              <>
                <span className="h-2 w-2 rounded-full bg-chart-2 animate-pulse" />
                Recovery Mode
              </>
            ) : (
              <>
                <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
                System Active
              </>
            )}
          </div>
        </div>
      </div>

      {/* Notification Popup */}
      <NotificationPopup
        show={showNotification}
        onClose={() => setShowNotification(false)}
        onStartRecovery={startRecovery}
        explanation={driftExplanation}
      />
    </div>
  )
}
